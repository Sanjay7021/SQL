SET @myjson = '[
	{
		"id":6790035,
		"name":"Anuja Gupta Sr.",
		"email":"gupta_anuja_sr@boyer.example",
		"gender":"female",
		"status":"active"
    },
	{
		"id":6790033,
        "name":"Pres. Shakti Varman",
        "email":"varman_pres_shakti@rolfson-simonis.example",
        "gender":"male",
        "status":"active"
	},
	{
		"id":6790032,
        "name":"Kamlesh Mukhopadhyay",
        "email":"mukhopadhyay_kamlesh@harris.test",
        "gender":"female","status":"inactive"
	},
	{
		"id":6790031,
		"name":"Lakshmi Menon",
		"email":"lakshmi_menon@okeefe-smith.example",
		"gender":"female",
		"status":"inactive"
    },
	{
		"id":6790030,
		"name":"Bhavani Kaul",
		"email":"bhavani_kaul@kuhn-block.test",
		"gender":"female",
		"status":"active"
    },
	{
		"id":6790029,
		"name":"Gautami Menon",
		"email":"gautami_menon@johns.test",
		"gender":"female",
		"status":"active"
    },
	{
		"id":6790028,
		"name":"Dinkar Malik",
		"email":"malik_dinkar@howell.test",
		"gender":"female",
		"status":"inactive"
    },
	{
		"id":6790027,
		"name":"Shridevi Dutta",
		"email":"dutta_shridevi@kunze-moen.test",
		"gender":"female",
		"status":"active"
    },
	{
		"id":6790026,
		"name":"Indira Butt",
		"email":"butt_indira@stanton.test",
		"gender":"female",
		"status":"active"
    },
	{
		"id":6790025,
		"name":"Lakshmi Ahuja",
		"email":"ahuja_lakshmi@erdman-swift.example",
		"gender":"female",
		"status":"active"
    }
]';

insert into json_data SELECT * FROM 
JSON_TABLE(
	@myjson,
    '$[*]' COLUMNS (
		id INT PATH '$.id',
        name1 VARCHAR(40) PATH '$.name',
        email VARCHAR(80) PATH '$.email',
        gender ENUM('male','female') PATH '$.gender',
        status1 ENUM('active','inactive') PATH '$.status'
        )
    ) AS json_tab;
   
create table json_data (
	id INT,
    name1 varchar(40),
    email varchar(80),
    gender enum('male','female'),
    status1 enum('active','inactive')
);

SELECT JSON_PRETTY((SELECT JSON_ARRAYAGG(JSON_OBJECT("id", id, "name", name1,"email",email,"gender",gender, "status", status1)) FROM json_data));
