DROP PROCEDURE InsertNumbers()

DELIMITER $$
CREATE PROCEDURE InsertNumbers()
BEGIN
	CREATE TEMPORARY TABLE IF NOT EXISTS Numbers (value INT);
    SET @i = 1;
    WHILE @i <= 5 DO
		INSERT INTO Numbers(value) VALUES(@i);
        SET @i = @i + 1;
	END WHILE;
SELECT * FROM Numbers;
    DROP TEMPORARY TABLE IF EXISTS Numbers;
END$$
DELIMITER ;

CALL InsertNumbers();