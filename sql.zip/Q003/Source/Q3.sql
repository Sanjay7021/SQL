use exam;
Alter table Asset rename column Name to AssetName;
select * from Asset;
drop procedure assetdata;
Delimiter //
create procedure assetdata(in data json)
begin
	if json_valid(data)=1
    then 
		insert into Asset( AssetID, AssetName, BrandName, 
		PurchasedDate, Warranty) select AssetID, AssetName, BrandName, 
		PurchasedDate, Warranty from json_table(data, "$[*]"
		columns(
			AssetID int path "$.AssetID",
			AssetName varchar(30) path "$.AssetName",
			BrandName varchar(20) path "$.BrandName",
			PurchasedDate date path "$.PurchasedDate",
			Warranty varchar(10) path "$.Warranty"
			) 
		)as temp ;
    end if;
    
end //
delimiter ;

set @asset = '[

        {
			"AssetID" : 7,
            "AssetName": "Motherboard1",

            "BrandName":"Dell",

            "PurchasedDate":"2022-01-01",

            "Warranty": "Yes"

        },

        {
			"AssetID" : 8,
            "AssetName": "laptop002",

            "BrandName":"Dell",

            "PurchasedDate":"2022-01-03",

            "Warranty": "No"

        }  ,

        {
			"AssetID" : 9,
            "AssetName": "Laptop003",

            "BrandName":"Dell",

            "PurchasedDate":"2022-01-04",

            "Warranty": "Yes"

        },

        {
			"AssetID" : 10,
			"AssetName": "Laptop004",

            "BrandName":"Lenovo",

            "PurchasedDate":"2022-01-04",

            "Warranty": "Yes"

        }

]';
call assetdata(@asset);


select * from Asset;

-- ------------------------------------------------------------------


Delimiter //
create procedure allocationdata(in data json)
begin
	if json_valid(data)=1
    then 
		insert into Allocation( AssetID, UserID) select AssetID, UserID
        from json_table(data, "$[*]"
		columns(
			AssetID int path "$.AssetID",
			UserID int path "$.UserID"
			) 
		)as temp where AssetID in (select AssetID from Allocation where AssetID = (select AssetID from Asset where Status="inStock"));
    end if;
    
end //
delimiter ;

set @allocation = '{

    "UserId": "3",

    "AssetsID": [

        1,

        4,

        6

    ]

}';
call allocationdata(@allocation);

select * from Allocation;



















