use exam;

create table User
(
	UserID int primary key,
    UserName varchar(30),
    CreatedDate date,
    EmailID varchar(50) unique
);

create table Asset
(
	AssetID int primary key,
    Name varchar(30),
    BrandName varchar(20),
    PurchasedDate date,
    Warranty varchar(10),
    Status varchar(20) check (Status in ("INSTOCK","Assigned","Scraped")) default  "InStock"
);


create table Allocation
(
	AssetId int,
    UserID int,
    AllocationDate date,
    constraint UserID primary key(AssetId)
);

insert into User
(UserID, UserName, CreatedDate, EmailID)
values
(1, "Rohan", "2022-01-03", "Rohan@gmail.com"),
(2, "Megha", "2022-02-03", "megha@gmail.com"),
(3, "Reema", "2022-01-02", "reema@gmail.com"),
(4, "Mitul", "2022-02-03", "mitul@gmail.com");

select * from User;

insert into Asset
(AssetID, Name, BrandName, PurchasedDate,Warranty, Status)
values
(1, "Keyboard001", "Logitech", "2021-01-01", "Yes", "Assigned"),
(2, "Mouse001", "HP", "2021-02-01", "Yes", "Assigned"),
(3, "Keyboard002", "Logitech", "2021-03-01", "No", "Scraped"),
(4, "Keyboard003", "HP", "2021-03-01", "Yes", "InStock"),
(5, "Monitor002", "HP", "2021-02-01", "Yes", "Assigned"),
(6, "Monitor003", "HP", "2021-02-01", "Yes", "Assigned");

select * from Asset;

insert into Allocation
(AssetID,UserID,AllocationDate)
values
(1,1,"2022-03-01"),
(5,1,"2022-03-01"),
(6,2,"2022-04-01"),
(2,2,"2022-04-01");

select * from Allocation;


update Asset 
set BrandName = "Logitech"
where AssetID in 
(select AssetID from Allocation 
where UserID = 
(select UserID from User 
where UserName = "Megha")
);

select * from Asset;