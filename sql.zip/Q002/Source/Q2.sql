use exam;


select * from Allocation;
select * from Asset;
select * from User;

create view data1
as
(
	select * from Asset
    where AssetID not in 
    (select AssetID from Allocation) and Status = "InStock"
);

select * from data1;

-- --------------------------------------------------------------------

create view data2 as
(select BrandName, group_concat(AssetName) as AssetNames, count(AssetName) as NoofAssets
from Asset group by BrandName);

select * from data2;
-- -----------------------------------------

create view data3 as
(select (select UserName from User where UserID = a.UserID) as UserName,
u.AssetName, u.BrandName, u.Warranty, u.Status, a.AllocationDate from Asset as u
left join Allocation as a 
on a.AssetId = u.AssetID);

select * from data3;
-- ----------------------------------------------------------------------------
create view  data4 as
(select * from Asset where Status = "Scraped");
select * from data4;

select * from data4;
-- ---------------------------------------------

create view data5 as
(select BrandName from Asset group by BrandName having count(AssetName) > 2);

select * from data5;